#include <stdio.h>

int     size(char *dest)
{
        int     i;

        i = 0;
        while (dest[i] != '\0')
                i++;
        return (i);
}

char    *ft_strcat(char *dest, char *src)
{
        int     i;
        int     s;

        s = size(dest);
        i = 0;
        while (src[i] != '\0')
        {
                dest[i + s] = src[i];
                i++;
        }
        dest[i + s] = '\0';
        return (dest);
}

char	*numtotext(int num)
{
	if(num == 0)
		return ("Zero");
	char *arr[] = {"","One","Two","Three","Four","Five","Six","Seven", "Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen", "Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"};
        
       	if (num >= 1 && num <= 19)
   	{
	       	return  (arr[num]); 
    	}
       	else
	return(0);      	
}

int main()
{
       	int Number = 10 ;
	printf("\n%s",numtotext(Number));
	
	return 0;
}
