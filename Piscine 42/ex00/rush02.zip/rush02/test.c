/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aoraikat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/05 16:40:29 by aoraikat          #+#    #+#             */
/*   Updated: 2025/07/05 16:49:39 by aoraikat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	size(char *dest)
{
	int	i;
	
	i = 0;
	while (dest[i] != '\0')
		i++;
	return (i);
}

char	*ft_strcat(char *dest, char *src)
{
	int	i;
	int	s;

	i = 0;
	s = size(dest);
	while (src[i] != '\0')
	{
		dest[i + s] = src[i];
		i++;
	}
	dest[i + s] = '\0';
	return (dest);
}

char	*numtotext(int num)
{
	static char	buffer[100]; 
	char	*arr1[] = {"","One","Two","Three","Four","Five","Six","Seven","Eight","Nine",
                    "Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen",
                    "Sixteen","Seventeen","Eighteen","Nineteen"};
	char	*arr2[] = {"","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"};
	

	buffer[0] = '\0';
	if (num == 0)
		return "Zero";
	if (num >= 1 && num <= 19)
		ft_strcat(buffer, arr1[num]);
	else if (num >= 20 && num <= 99)
	{
		int	x;
		int	y;
		
		x = num / 10;
		y = num % 10;
		ft_strcat(buffer, arr2[x]);
		if (y != 0)
		{
			ft_strcat(buffer, " ");
			ft_strcat(buffer, arr1[y]);
		}
	}
	else
		ft_strcat(buffer, "Number too big");
	return buffer;
}
/*
int main()
{
    int Number = 42;
    printf("\n%s\n", numtotext(Number));
    return 0;
}*/
